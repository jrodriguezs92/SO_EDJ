
***********************************************************

	Instituto Tecnológico de Costa Rica
	Computer Engineering

	Programmer: Esteban Agüero Pérez (estape11)

	Last update: 04/04/2019

	Operating Systems Principles
	Professor. Diego Vargas

***********************************************************

> This folder includes the library itself and a small test
> To compile 
	$ make all

> To run the general test
	$ ./bin/mainTest X
	> With X the scheduling algorithm to execute (SRR=0, LOTTERY=1, RT=1, RR=3)

> To run the mutex test
	$ ./bin/mainMutex